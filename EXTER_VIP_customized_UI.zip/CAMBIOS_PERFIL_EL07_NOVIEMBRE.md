# Cambios EL_07

- Después de validar la KEY, se muestra la pantalla de selección de perfil con FREE FIRE MAX.
- Al pulsar ENTRAR se abre la interfaz que corresponde al tipo de licencia (administrador o usuario).
- Se sustituyó el icono de Sonic por la imagen del ángel suministrada, tanto en el icono de la app como en el selector de perfil.
- Se quitó el acceso visible a MANTENIMIENTO dentro de Ajustes. La comprobación global que ya existía en el arranque se conserva.

La IPA debe compilarse y firmarse en Xcode con el equipo y perfil de firma del propietario.
