# EXTERNAL V1 V16 — pantalla completa y acceso por licencia

## Fondo de inicio
- Sonic ahora usa `scaledToFill`, ocupa el ancho y alto disponibles y se recorta al límite de pantalla.
- Se eliminó el fondo negro que aparecía al usar `scaledToFit`.

## Acceso protegido
- Se eliminó la ruta `DEBUG_PATCHES` que podía mostrar el menú de patches sin pasar por la validación.
- Sin una licencia válida (`role == nil`), siempre se muestra el menú de KEY.
- Al iniciar, `restoreSavedKey()` intenta validar la licencia guardada en Keychain.
- Si la validación tiene éxito, el usuario entra automáticamente al menú que corresponde a su rol.
- Si no hay key guardada o la validación falla, permanece en el menú de KEY.

## Validación
- Se comprobó la estructura y la integridad del ZIP.
- No se ejecutó una compilación de Xcode en este entorno; debe compilarse y probarse en Xcode.
